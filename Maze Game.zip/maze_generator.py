# ============================================================
# maze_generator.py
# Generates a perfect maze using Recursive Backtracking (DFS).
#
# Algorithm Overview:
#   1. Start at cell (0, 0), mark it visited.
#   2. Randomly pick an unvisited neighbour.
#   3. Carve a passage (remove the shared wall).
#   4. Recurse into the neighbour.
#   5. Backtrack when no unvisited neighbours remain.
#
# Complexity:
#   Time:  O(V)  — every cell is visited exactly once.
#   Space: O(V)  — recursion stack depth ≤ V cells.
#   (V = rows × cols)
# ============================================================

import random
import time


class Cell:
    """Represents a single cell in the maze grid."""

    def __init__(self, row: int, col: int):
        self.row = row
        self.col = col
        # Walls: True = wall present, False = passage open
        self.walls = {
            "N": True,   # North (up)
            "S": True,   # South (down)
            "E": True,   # East  (right)
            "W": True,   # West  (left)
        }
        self.visited = False   # Has DFS visited this cell?


class Maze:
    """
    A randomly generated perfect maze.
    'Perfect' means exactly one path exists between any two cells.
    """

    # Opposite direction look-up
    _OPPOSITE = {"N": "S", "S": "N", "E": "W", "W": "E"}
    # Direction → (row_delta, col_delta)
    _DELTA = {"N": (-1, 0), "S": (1, 0), "E": (0, 1), "W": (0, -1)}

    def __init__(self, rows: int, cols: int):
        self.rows = rows
        self.cols = cols
        self.grid: list[list[Cell]] = [
            [Cell(r, c) for c in range(cols)] for r in range(rows)
        ]
        self.gen_time_ms: float = 0.0   # measured generation time

    # ------------------------------------------------------------------
    # Public API
    # ------------------------------------------------------------------

    def generate(self) -> None:
        """Carve passages with iterative DFS (avoids Python recursion limit)."""
        start = time.perf_counter()

        stack: list[Cell] = []
        start_cell = self.grid[0][0]
        start_cell.visited = True
        stack.append(start_cell)

        while stack:
            current = stack[-1]
            neighbours = self._unvisited_neighbours(current)

            if neighbours:
                # Pick a random unvisited neighbour
                direction, neighbour = random.choice(neighbours)
                # Remove the wall between current and neighbour
                current.walls[direction] = False
                neighbour.walls[self._OPPOSITE[direction]] = False
                # Visit the neighbour
                neighbour.visited = True
                stack.append(neighbour)
            else:
                # Dead end — backtrack
                stack.pop()

        self.gen_time_ms = (time.perf_counter() - start) * 1000

    def cell(self, row: int, col: int) -> Cell:
        """Return the Cell at (row, col)."""
        return self.grid[row][col]

    def has_wall(self, row: int, col: int, direction: str) -> bool:
        """True if there is a wall in *direction* from cell (row, col)."""
        return self.grid[row][col].walls[direction]

    def reset_visited(self) -> None:
        """Clear visited flags so BFS can reuse them."""
        for row in self.grid:
            for cell in row:
                cell.visited = False

    # ------------------------------------------------------------------
    # Private helpers
    # ------------------------------------------------------------------

    def _unvisited_neighbours(self, cell: Cell) -> list:
        """Return list of (direction, Cell) for every unvisited neighbour."""
        result = []
        for direction, (dr, dc) in self._DELTA.items():
            nr, nc = cell.row + dr, cell.col + dc
            if 0 <= nr < self.rows and 0 <= nc < self.cols:
                neighbour = self.grid[nr][nc]
                if not neighbour.visited:
                    result.append((direction, neighbour))
        return result
