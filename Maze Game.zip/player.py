# ============================================================
# player.py
# Manages player state: position, movement, step counter.
# ============================================================

from maze_generator import Maze


# Maps arrow-key directions to maze wall names and grid deltas
_MOVE = {
    "N": (-1,  0),   # Up
    "S": ( 1,  0),   # Down
    "W": ( 0, -1),   # Left
    "E": ( 0,  1),   # Right
}


class Player:
    """The player character that navigates the maze."""

    def __init__(self, start_row: int = 0, start_col: int = 0):
        self.row: int = start_row
        self.col: int = start_col
        self.steps: int = 0

    # ------------------------------------------------------------------

    def move(self, direction: str, maze: Maze) -> bool:
        """
        Try to move one cell in *direction* ('N', 'S', 'E', 'W').

        Returns True if movement was successful, False if blocked by wall.
        """
        if maze.has_wall(self.row, self.col, direction):
            return False   # Wall blocks movement

        dr, dc = _MOVE[direction]
        self.row += dr
        self.col += dc
        self.steps += 1
        return True

    def reset(self, row: int = 0, col: int = 0) -> None:
        """Teleport player back to the given cell (default: top-left)."""
        self.row = row
        self.col = col
        self.steps = 0

    def position(self) -> tuple[int, int]:
        """Return (row, col)."""
        return (self.row, self.col)
