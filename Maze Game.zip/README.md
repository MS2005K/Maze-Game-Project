# 2D Maze Solver Game — Analysis of Algorithms

A fully playable **2D top-down maze game** built with Python 3 + Pygame.
The player navigates a randomly generated maze and can visualise the shortest
path with one key-press.

---

## Features

| Feature | Detail |
|---|---|
| Maze Generation | Recursive Backtracking (DFS) |
| Shortest Path | Breadth-First Search (BFS) |
| Difficulty levels | Easy (10×10), Medium (20×20), Hard (30×30) |
| HUD | Live timer, step counter, difficulty label |
| Path visualisation | Yellow BFS overlay toggled with **S** |
| Win screen | Congratulations overlay with stats |

---

## Project Structure

```
maze_solver_2d/
├── main.py             ← Entry point / game loop
├── maze_generator.py   ← DFS maze generation
├── path_solver.py      ← BFS shortest path
├── player.py           ← Player state & movement
├── ui.py               ← All Pygame rendering
├── settings.py         ← Colours, fonts, constants
├── requirements.txt
└── README.md
```

---

## Installation & Run

```bash
pip install -r requirements.txt
python main.py
```

Requires **Python 3.10+**.

---

## Controls

| Key | Action |
|---|---|
| ↑ ↓ ← → | Move player |
| S | Show / hide shortest path |
| R | Restart current maze |
| N | Generate new maze |
| 1 | Easy (10 × 10) |
| 2 | Medium (20 × 20) |
| 3 | Hard (30 × 30) |
| Q / ESC | Quit |

---

## Algorithm Complexity

### DFS Maze Generation
- **Time:** O(V) — each cell visited exactly once  
- **Space:** O(V) — iterative stack depth

### BFS Shortest Path
- **Time:** O(V + E) — cells + open passages  
- **Space:** O(V) — parent dictionary + queue

*(V = total cells, E = open passages)*

---

## Real-World Applications

- GPS / navigation routing  
- Robot path planning  
- Emergency evacuation systems  
- Game AI pathfinding (A\*)

---

## Author

*Analysis of Algorithms — Course Project*
