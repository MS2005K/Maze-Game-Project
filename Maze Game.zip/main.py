# ============================================================
# main.py  —  2D Maze Solver Game
#
# Controls:
#   Arrow keys  — Move player
#   E           — Easy   (10x10) new maze
#   M           — Medium (20x20) new maze
#   H           — Hard   (30x30) new maze
#   1 / 2 / 3   — Same as E / M / H
#   S           — Show / hide BFS shortest path
#   A           — Auto-solve: animate BFS path step by step
#                 (press A again to cancel)
#   R           — Restart current maze (reset player)
#   N           — Generate new maze (same difficulty)
#   Q / ESC     — Quit
# ============================================================

import sys
import time
import pygame

from settings import WINDOW_TITLE, HUD_HEIGHT, FPS, LEVELS
from maze_generator import Maze
from path_solver    import bfs_shortest_path
from player         import Player
from ui             import Renderer


# ── Helpers ───────────────────────────────────────────────────────────

def compute_cell_size(rows, cols, screen_w, screen_h):
    from settings import FONT_HUD_SIZE
    hint_area = 10 * (FONT_HUD_SIZE + 2) + 20
    usable_h  = screen_h - HUD_HEIGHT - hint_area
    usable_w  = screen_w - 20
    return max(4, min(usable_w // cols, usable_h // rows, 32))


def maze_origin(rows, cols, cell_size, screen_w):
    ox = (screen_w - cols * cell_size) // 2
    oy = HUD_HEIGHT + 6
    return ox, oy


def apply_difficulty(difficulty, screen_w, screen_h):
    """Create a fresh maze + player and return all state pieces."""
    size   = LEVELS[difficulty]
    maze   = Maze(size, size)
    maze.generate()
    cs     = compute_cell_size(size, size, screen_w, screen_h)
    origin = maze_origin(size, size, cs, screen_w)
    player = Player(0, 0)
    exit_pos = (size - 1, size - 1)
    return maze, player, [], cs, origin, exit_pos, time.time()


# ── Main loop ─────────────────────────────────────────────────────────

def main():
    pygame.init()

    screen_w, screen_h = 900, 750
    screen = pygame.display.set_mode((screen_w, screen_h))
    pygame.display.set_caption(WINDOW_TITLE)
    clock = pygame.time.Clock()
    renderer = Renderer(screen)

    # Initial state
    difficulty = "Easy"
    maze, player, path, cs, origin, exit_pos, start_time = \
        apply_difficulty(difficulty, screen_w, screen_h)

    show_path    = False
    won          = False
    elapsed      = 0.0

    # Auto-solve state
    auto_solving    = False
    auto_path       = []
    auto_step_index = 0
    AUTO_DELAY_MS   = 80
    auto_last_ms    = 0

    running = True
    while running:
        clock.tick(FPS)

        if not won:
            elapsed = time.time() - start_time

        # ── Auto-solve animation tick ────────────────────────────────
        if auto_solving and not won:
            now = pygame.time.get_ticks()
            if now - auto_last_ms >= AUTO_DELAY_MS:
                auto_last_ms = now
                if auto_step_index < len(auto_path):
                    r, c = auto_path[auto_step_index]
                    player.row   = r
                    player.col   = c
                    player.steps = auto_step_index
                    auto_step_index += 1
                    # Yellow trail = remaining path
                    path, _ = bfs_shortest_path(maze, player.position(), exit_pos)
                    show_path = True
                    if player.position() == exit_pos:
                        won          = True
                        auto_solving = False
                else:
                    auto_solving = False

        # ── Events ───────────────────────────────────────────────────
        for event in pygame.event.get():
            if event.type == pygame.QUIT:
                running = False

            elif event.type == pygame.KEYDOWN:
                k = event.key

                # Quit
                if k in (pygame.K_q, pygame.K_ESCAPE):
                    running = False

                # ── Difficulty keys ──────────────────────────────────
                elif k in (pygame.K_e, pygame.K_1):
                    difficulty = "Easy"
                    maze, player, path, cs, origin, exit_pos, start_time = \
                        apply_difficulty(difficulty, screen_w, screen_h)
                    show_path = won = auto_solving = False
                    elapsed = 0.0

                elif k in (pygame.K_m, pygame.K_2):
                    difficulty = "Medium"
                    maze, player, path, cs, origin, exit_pos, start_time = \
                        apply_difficulty(difficulty, screen_w, screen_h)
                    show_path = won = auto_solving = False
                    elapsed = 0.0

                elif k in (pygame.K_h, pygame.K_3):
                    difficulty = "Hard"
                    maze, player, path, cs, origin, exit_pos, start_time = \
                        apply_difficulty(difficulty, screen_w, screen_h)
                    show_path = won = auto_solving = False
                    elapsed = 0.0

                # New maze (same difficulty)
                elif k == pygame.K_n:
                    maze, player, path, cs, origin, exit_pos, start_time = \
                        apply_difficulty(difficulty, screen_w, screen_h)
                    show_path = won = auto_solving = False
                    elapsed = 0.0

                # Restart same maze
                elif k == pygame.K_r:
                    player.reset(0, 0)
                    path         = []
                    show_path    = False
                    won          = False
                    auto_solving = False
                    start_time   = time.time()
                    elapsed      = 0.0

                # Show / hide BFS path
                elif k == pygame.K_s:
                    if not won and not auto_solving:
                        show_path = not show_path
                        if show_path:
                            path, _ = bfs_shortest_path(
                                maze, player.position(), exit_pos)
                        else:
                            path = []

                # ── Auto-solve (A) ────────────────────────────────────
                elif k == pygame.K_a:
                    if won:
                        pass
                    elif auto_solving:
                        # Cancel animation
                        auto_solving = False
                        show_path    = False
                        path         = []
                    else:
                        full_path, _ = bfs_shortest_path(
                            maze, player.position(), exit_pos)
                        if full_path and len(full_path) > 1:
                            auto_path       = full_path
                            auto_step_index = 1
                            auto_solving    = True
                            auto_last_ms    = pygame.time.get_ticks()
                            show_path       = True
                            path, _         = bfs_shortest_path(
                                maze, player.position(), exit_pos)

                # ── Manual movement ───────────────────────────────────
                elif not won and not auto_solving:
                    moved = False
                    if k == pygame.K_UP:
                        moved = player.move("N", maze)
                    elif k == pygame.K_DOWN:
                        moved = player.move("S", maze)
                    elif k == pygame.K_LEFT:
                        moved = player.move("W", maze)
                    elif k == pygame.K_RIGHT:
                        moved = player.move("E", maze)

                    if moved and show_path:
                        path, _ = bfs_shortest_path(
                            maze, player.position(), exit_pos)

                    if player.position() == exit_pos:
                        won = True

        # ── Render ───────────────────────────────────────────────────
        renderer.draw(
            maze         = maze,
            cell_size    = cs,
            player_pos   = player.position(),
            exit_pos     = exit_pos,
            elapsed_sec  = elapsed,
            steps        = player.steps,
            difficulty   = difficulty,
            path         = path,
            show_path    = show_path,
            won          = won,
            maze_origin  = origin,
            auto_solving = auto_solving,
        )
        pygame.display.flip()

    pygame.quit()
    sys.exit()


if __name__ == "__main__":
    main()
