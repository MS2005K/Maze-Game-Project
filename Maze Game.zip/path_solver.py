# ============================================================
# path_solver.py
# Finds the shortest path inside the maze using BFS.
#
# Algorithm Overview:
#   1. Enqueue the player's start position.
#   2. Expand each cell level by level (FIFO queue).
#   3. For each dequeued cell, enqueue open (wall-less) neighbours
#      that have not yet been visited.
#   4. Record each cell's parent so the path can be reconstructed.
#   5. Stop when the exit cell is dequeued.
#   6. Walk the parent chain backwards to get the shortest path.
#
# Complexity:
#   Time:  O(V + E)  — V cells, E open passages.
#   Space: O(V)      — parent dict + visited set.
# ============================================================

import time
from collections import deque
from maze_generator import Maze


# Direction look-up: direction → (row_delta, col_delta)
_DELTA = {"N": (-1, 0), "S": (1, 0), "E": (0, 1), "W": (0, -1)}


def bfs_shortest_path(
    maze: Maze,
    start: tuple[int, int],
    exit_pos: tuple[int, int],
) -> tuple[list[tuple[int, int]], float]:
    """
    Compute the shortest path from *start* to *exit_pos*.

    Parameters
    ----------
    maze      : Maze object (already generated).
    start     : (row, col) of the player / source.
    exit_pos  : (row, col) of the exit cell.

    Returns
    -------
    path      : Ordered list of (row, col) from start → exit.
                Empty list if no path exists (should never happen
                in a perfect maze).
    elapsed_ms: Time taken by BFS in milliseconds.
    """
    t0 = time.perf_counter()

    queue: deque[tuple[int, int]] = deque()
    queue.append(start)

    # parent[cell] = cell that discovered it
    parent: dict[tuple[int, int], tuple[int, int] | None] = {start: None}

    while queue:
        current = queue.popleft()

        if current == exit_pos:
            break  # Found the exit — reconstruct and return

        row, col = current
        cell = maze.cell(row, col)

        for direction, (dr, dc) in _DELTA.items():
            # Only traverse if the wall in this direction is absent
            if not cell.walls[direction]:
                neighbour = (row + dr, col + dc)
                if neighbour not in parent:          # not yet visited
                    parent[neighbour] = current
                    queue.append(neighbour)

    elapsed_ms = (time.perf_counter() - t0) * 1000

    # Reconstruct path by walking the parent chain backwards
    path: list[tuple[int, int]] = []
    node: tuple[int, int] | None = exit_pos
    while node is not None:
        path.append(node)
        node = parent.get(node)

    path.reverse()

    # If path doesn't start at 'start', BFS never reached exit
    if not path or path[0] != start:
        return [], elapsed_ms

    return path, elapsed_ms
