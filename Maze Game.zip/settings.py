# ============================================================
# settings.py — Global constants for the 2D Maze Solver Game
# ============================================================

# --- Window ---
WINDOW_TITLE = "2D Maze Solver — Analysis of Algorithms"
HUD_HEIGHT   = 70

# --- Difficulty levels ---
LEVELS = {
    "Easy":   10,
    "Medium": 20,
    "Hard":   30,
}

# --- Cell rendering ---
CELL_SIZE  = 28
WALL_WIDTH = 2

# --- Colours ---
# Background layers
COL_BG_TOP     = (8,   10,  28)   # deep space navy  (top of gradient)
COL_BG_BOT     = (18,  26,  52)   # midnight blue     (bottom of gradient)
COL_BG         = (8,   10,  28)   # solid fallback

# Maze
COL_WALL       = (80,  140, 220)  # electric blue wall
COL_WALL_GLOW  = (30,  80,  160)  # glow behind walls
COL_START      = (39,  200, 110)  # neon emerald start
COL_EXIT       = (220,  60,  60)  # neon red exit
COL_PLAYER     = (80,  190, 255)  # bright cyan player
COL_PATH       = (255, 210,  40)  # golden yellow BFS path

# HUD
COL_HUD_BG     = (12,  16,  38)   # very dark panel
COL_HUD_TEXT   = (200, 220, 255)  # ice blue text
COL_HUD_ACCENT = (80,  200, 255)  # bright cyan accent

# Overlays
COL_WIN_TEXT   = (80,  255, 160)  # neon green win
COL_KEY_LABEL  = (120, 150, 200)  # muted blue hint text
COL_KEY_KEY    = (200, 225, 255)  # bright key names

# Grid dots (decorative background)
COL_GRID_DOT   = (25,  40,  80)   # subtle dot colour

# Stars
COL_STAR       = (255, 255, 255)

# --- Frame rate ---
FPS = 60

# --- Font sizes ---
FONT_HUD_SIZE  = 18
FONT_BIG_SIZE  = 38
FONT_HINT_SIZE = 14
