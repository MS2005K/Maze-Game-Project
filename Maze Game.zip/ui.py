# ============================================================
# ui.py  —  All Pygame rendering for the 2D Maze Solver Game
#
# Visual layers (back to front):
#   1. Animated gradient background + star field + dot grid
#   2. Maze cell fills (start, exit, BFS path)
#   3. Wall lines with subtle inner glow
#   4. Player (glowing animated circle)
#   5. HUD bar (top)
#   6. Key-hint panel (below maze)
#   7. Win overlay
# ============================================================

import math
import random
import pygame

from settings import (
    HUD_HEIGHT, WALL_WIDTH,
    COL_BG, COL_BG_TOP, COL_BG_BOT,
    COL_WALL, COL_WALL_GLOW,
    COL_START, COL_EXIT,
    COL_PLAYER, COL_PATH,
    COL_HUD_BG, COL_HUD_TEXT, COL_HUD_ACCENT,
    COL_WIN_TEXT, COL_KEY_LABEL, COL_KEY_KEY,
    COL_GRID_DOT,
    FONT_HUD_SIZE, FONT_BIG_SIZE, FONT_HINT_SIZE,
)
from maze_generator import Maze


# ── Pre-computed star field (shared across all frames) ────────────────
random.seed(42)
_STARS = [
    (random.randint(0, 900), random.randint(0, 750),
     random.random(),            # brightness 0-1
     random.choice([1, 1, 2]))   # radius
    for _ in range(180)
]


class Renderer:
    """Draws every visual element of the game onto a Pygame surface."""

    _HINTS = [
        ("Arrow keys", "Move player"),
        ("E / 1",      "Easy   (10×10)"),
        ("M / 2",      "Medium (20×20)"),
        ("H / 3",      "Hard   (30×30)"),
        ("S",          "Show shortest path"),
        ("A",          "Auto-solve  (A again = cancel)"),
        ("R",          "Restart maze"),
        ("N",          "New maze"),
        ("Q",          "Quit"),
    ]

    def __init__(self, screen: pygame.Surface):
        self.screen  = screen
        self._tick   = 0          # frame counter for animations
        pygame.font.init()
        self.font_hud  = pygame.font.SysFont("consolas", FONT_HUD_SIZE, bold=True)
        self.font_big  = pygame.font.SysFont("consolas", FONT_BIG_SIZE, bold=True)
        self.font_hint = pygame.font.SysFont("consolas", FONT_HINT_SIZE)
        self.font_key  = pygame.font.SysFont("consolas", FONT_HINT_SIZE, bold=True)

    # ── Master draw call ──────────────────────────────────────────────

    def draw(self, maze, cell_size, player_pos, exit_pos,
             elapsed_sec, steps, difficulty,
             path, show_path, won, maze_origin,
             auto_solving=False):
        self._tick += 1
        w, h = self.screen.get_size()

        # 1. Gradient background + stars + dot grid
        self._draw_background(w, h)

        # 2. Maze contents + walls
        self._draw_maze(maze, cell_size, maze_origin, path, show_path,
                        player_pos, exit_pos)

        # 3. HUD
        self._draw_hud(elapsed_sec, steps, difficulty, auto_solving, w)

        # 4. Hint panel
        self._draw_hints(maze, cell_size, maze_origin)

        # 5. Win overlay
        if won:
            self._draw_win(elapsed_sec, steps, w, h)

    # ── Background ────────────────────────────────────────────────────

    def _draw_background(self, w, h):
        """Vertical gradient + twinkling stars + subtle dot grid."""
        # --- Vertical gradient (draw horizontal strips) ---
        for y in range(0, h, 2):
            t   = y / h
            r   = int(COL_BG_TOP[0] + (COL_BG_BOT[0] - COL_BG_TOP[0]) * t)
            g   = int(COL_BG_TOP[1] + (COL_BG_BOT[1] - COL_BG_TOP[1]) * t)
            b   = int(COL_BG_TOP[2] + (COL_BG_BOT[2] - COL_BG_TOP[2]) * t)
            pygame.draw.line(self.screen, (r, g, b), (0, y), (w, y))
            pygame.draw.line(self.screen, (r, g, b), (0, y+1), (w, y+1))

        # --- Dot grid (futuristic graph-paper feel) ---
        for gx in range(0, w, 28):
            for gy in range(HUD_HEIGHT, h, 28):
                pygame.draw.circle(self.screen, COL_GRID_DOT, (gx, gy), 1)

        # --- Twinkling stars ---
        t_phase = self._tick * 0.04
        for (sx, sy, brightness, radius) in _STARS:
            # Sine-based twinkle
            alpha = 0.4 + 0.6 * abs(math.sin(t_phase + brightness * 6.28))
            bright = int(160 + 95 * alpha)
            colour = (bright, bright, min(255, bright + 30))
            pygame.draw.circle(self.screen, colour, (sx, sy), radius)

    # ── Maze ──────────────────────────────────────────────────────────

    def _draw_maze(self, maze, cs, origin, path, show_path,
                   player_pos, exit_pos):
        ox, oy  = origin
        rows, cols = maze.rows, maze.cols
        pulse   = 0.5 + 0.5 * math.sin(self._tick * 0.07)  # 0-1 pulse

        # ---- Cell backgrounds ----------------------------------------
        for r in range(rows):
            for c in range(cols):
                x = ox + c * cs
                y = oy + r * cs
                # Subtle inner cell colour (very dark blue)
                cell_col = (14, 20, 50)
                pygame.draw.rect(self.screen, cell_col, (x+1, y+1, cs-1, cs-1))

        # Start cell — glowing green
        self._draw_glow_cell(ox, oy, 0, 0, cs,
                             COL_START, (0, 80, 40), pulse)

        # Exit cell — glowing red
        er, ec = exit_pos
        self._draw_glow_cell(ox, oy, er, ec, cs,
                             COL_EXIT, (80, 0, 0), pulse)

        # BFS path — golden trail
        if show_path and path:
            for (pr, pc) in path:
                if (pr, pc) in ((0, 0), exit_pos):
                    continue
                x = ox + pc * cs + 3
                y = oy + pr * cs + 3
                w_  = cs - 5
                path_alpha = int(180 + 40 * pulse)
                col = (min(255, COL_PATH[0]),
                       min(255, COL_PATH[1]),
                       min(255, COL_PATH[2]))
                pygame.draw.rect(self.screen, col,
                                 (x, y, w_, w_), border_radius=2)

        # ---- Walls ---------------------------------------------------
        ww = max(1, WALL_WIDTH)
        for r in range(rows):
            for c in range(cols):
                cell = maze.cell(r, c)
                x    = ox + c * cs
                y    = oy + r * cs

                if cell.walls["N"]:
                    # Glow line behind main wall
                    pygame.draw.line(self.screen, COL_WALL_GLOW,
                                     (x-1, y), (x+cs+1, y), ww+2)
                    pygame.draw.line(self.screen, COL_WALL,
                                     (x, y), (x+cs, y), ww)

                if cell.walls["W"]:
                    pygame.draw.line(self.screen, COL_WALL_GLOW,
                                     (x, y-1), (x, y+cs+1), ww+2)
                    pygame.draw.line(self.screen, COL_WALL,
                                     (x, y), (x, y+cs), ww)

        # East border
        for r in range(rows):
            x = ox + cols * cs
            y = oy + r  * cs
            pygame.draw.line(self.screen, COL_WALL_GLOW,
                             (x, y-1), (x, y+cs+1), ww+2)
            pygame.draw.line(self.screen, COL_WALL,
                             (x, y), (x, y+cs), ww)

        # South border
        for c in range(cols):
            x = ox + c    * cs
            y = oy + rows * cs
            pygame.draw.line(self.screen, COL_WALL_GLOW,
                             (x-1, y), (x+cs+1, y), ww+2)
            pygame.draw.line(self.screen, COL_WALL,
                             (x, y), (x+cs, y), ww)

        # ---- Player --------------------------------------------------
        pr, pc  = player_pos
        px      = ox + pc * cs + cs // 2
        py      = oy + pr * cs + cs // 2
        radius  = max(3, cs // 2 - 3)

        # Animated outer glow rings
        for ring in range(3, 0, -1):
            alpha_r = int(30 + 20 * pulse) * ring // 3
            glow_r  = radius + ring * 3
            glow_col = (max(0, COL_PLAYER[0] - 60),
                        max(0, COL_PLAYER[1] - 20),
                        min(255, COL_PLAYER[2]))
            # Pygame has no alpha for draw.circle without Surface, fake it
            s = pygame.Surface((glow_r*2+2, glow_r*2+2), pygame.SRCALPHA)
            pygame.draw.circle(s, (*glow_col, alpha_r),
                               (glow_r+1, glow_r+1), glow_r)
            self.screen.blit(s, (px - glow_r - 1, py - glow_r - 1))

        # Solid player body
        pygame.draw.circle(self.screen, COL_PLAYER, (px, py), radius)
        # Bright specular highlight
        pygame.draw.circle(self.screen, (200, 240, 255),
                           (px - radius//3, py - radius//3),
                           max(2, radius // 3))

    def _draw_glow_cell(self, ox, oy, r, c, cs,
                        col_bright, col_dark, pulse):
        """Draw a cell with a coloured fill and a pulsing glow effect."""
        x = ox + c * cs + 1
        y = oy + r * cs + 1
        # Dark base
        pygame.draw.rect(self.screen, col_dark, (x, y, cs-1, cs-1))
        # Pulsing bright overlay using a Surface with alpha
        s = pygame.Surface((cs-1, cs-1), pygame.SRCALPHA)
        alpha = int(120 + 60 * pulse)
        pygame.draw.rect(s, (*col_bright, alpha), (0, 0, cs-1, cs-1))
        self.screen.blit(s, (x, y))

    # ── HUD bar ───────────────────────────────────────────────────────

    def _draw_hud(self, elapsed, steps, difficulty, auto_solving, w):
        # Panel
        pygame.draw.rect(self.screen, COL_HUD_BG, (0, 0, w, HUD_HEIGHT))
        # Bottom border line (electric blue)
        pygame.draw.line(self.screen, COL_WALL,
                         (0, HUD_HEIGHT-1), (w, HUD_HEIGHT-1), 2)

        mins = int(elapsed) // 60
        secs = int(elapsed) % 60

        items = [
            (f"Time  {mins:02d}:{secs:02d}", COL_HUD_TEXT),
            (f"Steps  {steps}",              COL_HUD_TEXT),
            (f"{difficulty}",                COL_HUD_ACCENT),
        ]
        if auto_solving:
            items.append(("AUTO-SOLVING...", (255, 210, 40)))

        total_w = sum(self.font_hud.size(txt)[0] for txt, _ in items)
        gap     = (w - total_w) // (len(items) + 1)
        x = gap
        for txt, col in items:
            surf = self.font_hud.render(txt, True, col)
            self.screen.blit(surf, (x, (HUD_HEIGHT - surf.get_height()) // 2))
            x += surf.get_width() + gap

    # ── Key hints ─────────────────────────────────────────────────────

    def _draw_hints(self, maze, cs, origin):
        ox, oy  = origin
        y       = oy + maze.rows * cs + 10
        col_w   = 95   # width of the key column

        for key, desc in self._HINTS:
            k_surf = self.font_key.render(key, True, COL_KEY_KEY)
            d_surf = self.font_hint.render(desc, True, COL_KEY_LABEL)
            self.screen.blit(k_surf, (ox, y))
            self.screen.blit(d_surf, (ox + col_w, y))
            y += k_surf.get_height() + 3

    # ── Win overlay ───────────────────────────────────────────────────

    def _draw_win(self, elapsed, steps, w, h):
        pulse = 0.5 + 0.5 * math.sin(self._tick * 0.08)

        # Semi-transparent dark overlay
        overlay = pygame.Surface((w, h), pygame.SRCALPHA)
        overlay.fill((0, 5, 20, 200))
        self.screen.blit(overlay, (0, 0))

        # Glowing panel
        pw, ph  = 460, 300
        px_     = (w - pw) // 2
        py_     = (h - ph) // 2
        panel_s = pygame.Surface((pw, ph), pygame.SRCALPHA)
        panel_s.fill((10, 20, 60, 230))
        self.screen.blit(panel_s, (px_, py_))
        # Panel border
        border_col = (
            int(COL_WALL[0] * (0.6 + 0.4 * pulse)),
            int(COL_WALL[1] * (0.6 + 0.4 * pulse)),
            int(COL_WALL[2] * (0.6 + 0.4 * pulse)),
        )
        pygame.draw.rect(self.screen, border_col,
                         (px_, py_, pw, ph), 2, border_radius=8)

        mins = int(elapsed) // 60
        secs = int(elapsed) % 60

        lines = [
            ("Congratulations!", self.font_big,  COL_WIN_TEXT),
            ("Maze Solved!",     self.font_hud,  COL_HUD_TEXT),
            ("",                 self.font_hint, COL_KEY_LABEL),
            (f"Steps :  {steps}", self.font_hud, COL_HUD_TEXT),
            (f"Time  :  {mins:02d}:{secs:02d}", self.font_hud, COL_HUD_TEXT),
            ("",                 self.font_hint, COL_KEY_LABEL),
            ("Press N for a new maze", self.font_hint, COL_KEY_LABEL),
        ]

        total_h = sum(f.size(t)[1] + 6 for t, f, _ in lines)
        cy = py_ + (ph - total_h) // 2

        for text, font, colour in lines:
            surf = font.render(text, True, colour)
            self.screen.blit(surf, ((w - surf.get_width()) // 2, cy))
            cy += surf.get_height() + 6
